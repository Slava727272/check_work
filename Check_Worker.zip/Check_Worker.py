from binance.spot import Spot
import telebot

API_KEY = '5834130945:AAGTBjhHVW6t-rYtGkdCH0LSoeBrvzSeY9A'
bot = telebot.TeleBot(API_KEY)
chat_id = '-1001896132857'

client = Spot(
            api_key='xQzg39mWJDhD46vGsr0O3gAa8ZW6lBFnJAOy5rwV5V7Vr6mrYeL0Y8Gt1MHd6aFT',
            api_secret='e3vlXzJvHehZ4aQLdPlhSekZik3oiG8JWQrQrRKIvxMhk6XvdPdyGnVVDgnAG8T6'
    )

l3squad = client.mining_worker_list(algo='Scrypt', userName='l3squad')
worker_list = l3squad.get('data').get('workerDatas')

# Коробки у Макса l3squad
for open_worker_list in worker_list:
    name_work = 'l3squad.' + open_worker_list.get('workerName')
    HashRate = str(round(int(open_worker_list.get('hashRate')) / 1000000, 2)) + ' Mh/s'
    dayHashRate = str(round(int(open_worker_list.get('dayHashRate')) / 1000000, 2)) + ' Mh/s (24ч.)'
    status = open_worker_list.get('status')

    if int(open_worker_list.get('workerName')) < 8:
        #if round(int(open_worker_list.get('dayHashRate')) / 1000000, 2) < 300:
        #    bot.send_message(chat_id, '*' + '@maxx3956\nНадо перезагрузить воркер: ' + str(name_work) + '\nМаленький хешрейт*', parse_mode='Markdown')
        if status != 1:
            bot.send_message(chat_id, '*' + '@maxx3956\nВыключился воркер: ' + str(name_work) + '*', parse_mode='Markdown')