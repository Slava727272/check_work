from binance.spot import Spot
import emoji
import telebot

maks_list = ['Макс:']
dacha_list = ['\nДача:']
API_KEY = '5834130945:AAGTBjhHVW6t-rYtGkdCH0LSoeBrvzSeY9A'
bot = telebot.TeleBot(API_KEY)
chat_id = '-1001896132857'

client = Spot(
            api_key='xQzg39mWJDhD46vGsr0O3gAa8ZW6lBFnJAOy5rwV5V7Vr6mrYeL0Y8Gt1MHd6aFT',
            api_secret='e3vlXzJvHehZ4aQLdPlhSekZik3oiG8JWQrQrRKIvxMhk6XvdPdyGnVVDgnAG8T6'
    )

l3squad = client.mining_worker_list(algo='Scrypt', userName='l3squad')
worker_list = l3squad.get('data').get('workerDatas')

# Коробки у Макса l3squad
#print('\nМакс:')
for open_worker_list in worker_list:
    name_work = 'l3squad.' + open_worker_list.get('workerName')
    HashRate = str(round(int(open_worker_list.get('hashRate')) / 1000000, 2)) + ' Mh/s'
    dayHashRate = str(round(int(open_worker_list.get('dayHashRate')) / 1000000, 2)) + ' Mh/s (24ч.)'
    status = open_worker_list.get('status')
    if int(open_worker_list.get('workerName')) < 8:
        if status != 1:
            maks_list.append(str(name_work) + ' - ' + str(HashRate) + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':red_circle:'))
        else:
            maks_list.append(str(name_work) + ' - ' + str(HashRate) + emoji.emojize(':pick:') + emoji.emojize(':construction_worker:') + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':green_circle:'))


# Коробки на Даче l3squad
#print('\nДача:')
for open_worker_list in worker_list:
    name_work = 'l3squad.' + open_worker_list.get('workerName')
    HashRate = str(round(int(open_worker_list.get('hashRate')) / 1000000, 2)) + ' Mh/s'
    dayHashRate = str(round(int(open_worker_list.get('dayHashRate')) / 1000000, 2)) + ' Mh/s (24ч.)'
    status = open_worker_list.get('status')

    if int(open_worker_list.get('workerName')) >= 8:
        if status != 1:
            dacha_list.append(str(name_work) + ' - ' + str(HashRate) + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':red_circle:'))
        else:
            dacha_list.append(str(name_work) + ' - ' + str(HashRate) + emoji.emojize(':pick:') + emoji.emojize(':construction_worker:') + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':green_circle:'))


#####################################
# Остальные названия воркеров на даче:
# BTC
#luckymining = client.mining_worker_list(algo='SHA256', userName='luckyminingteam')
#worker_bit = luckymining.get('data').get('workerDatas')
#for open_worker_bit in worker_bit:
#    name_work = 'S17 Pro'
#    HashRate = str(round(int(open_worker_bit.get('hashRate')) / 1000000000000, 2)) + ' Th/s'
#    dayHashRate = str(round(int(open_worker_bit.get('dayHashRate')) / 1000000000000, 2)) + ' Th/s (24ч.)'
#    status = open_worker_bit.get('status')
#    #print(name_work)
#    if status != 1:
#        dacha_list.append(
#            str(name_work) + ' - ' + str(HashRate) + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':red_circle:'))
#    else:
#        dacha_list.append(str(name_work) + ' - ' + str(HashRate) + emoji.emojize(':pick:') + emoji.emojize(':construction_worker:') + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':green_circle:'))

# LTC
#Litecoin1234 = client.mining_worker_list(algo='Scrypt', userName='Litecoin1234')
#worker_litecoin = Litecoin1234.get('data').get('workerDatas')
#for open_worker_litecoin in worker_litecoin:
#    name_work = 'L3+'
#    HashRate = str(round(int(open_worker_litecoin.get('hashRate')) / 1000000, 2)) + ' Mh/s'
#    dayHashRate = str(round(int(open_worker_litecoin.get('dayHashRate')) / 1000000, 2)) + ' Mh/s (24ч.)'
#    status = open_worker_litecoin.get('status')
#    #print(name_work)
#    if status != 1:
#        dacha_list.append(
#            str(name_work) + ' - ' + str(HashRate) + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':red_circle:'))
#    else:
#        dacha_list.append(str(name_work) + ' - ' + str(HashRate) + emoji.emojize(':pick:') + emoji.emojize(':construction_worker:') + ' | ' + str(dayHashRate) + ' - ' + emoji.emojize(':green_circle:'))

######################
# Денежная статистика:
ltc = client.mining_statistics_list(algo='Scrypt', userName='l3squad')
profit_ltc = float(ltc.get('data').get('profitYesterday').get('LTC'))
float_ltc = round(profit_ltc, 2)
tg_ltc = (str(profit_ltc) + ' LTC')

doge = client.mining_bonus_list(algo='Scrypt', userName='l3squad')
doge_list = doge.get('data').get('otherProfits')
profit_doge = doge_list[0].get('profitAmount')
float_doge = round(profit_doge, 2)
tg_doge = (str(float_doge) + ' DOGE')

#btc = client.mining_statistics_list(algo='SHA256', userName='luckyminingteam')
#profit_btc = float(btc.get('data').get('profitYesterday').get('BTC'))
#tg_btc = (str(profit_btc) + ' BTC')

kurs_ltc = float(client.avg_price(symbol='LTCUSDT').get('price'))
kurs_doge = float(client.avg_price(symbol='DOGEUSDT').get('price'))
#kurs_btc = float(client.avg_price(symbol='BTCUSDT').get('price'))

profit_1 = profit_ltc * kurs_ltc
profit_2 = profit_doge * kurs_doge
#profit_3 = profit_btc * kurs_btc
profit = round(profit_1 + profit_2, 2)


dohod = '\n' + 'Доход за вчерашний день:' + '\n' + str(tg_ltc) + '\n' + str(tg_doge) + '\n' + 'Примерный доход: ' + str(profit) + ' $'
#print(dohod)

#print(maks_list)
#print(dacha_list)
result_maks = "\n".join(str(maks_list[i]) for i in range(len(maks_list)))
result_dacha = "\n".join(str(dacha_list[a]) for a in range(len(dacha_list)))
shapka = 'Статистика ' + emoji.emojize(':money_bag:') + '\n\n'
notif = shapka + result_maks + '\n' + result_dacha + '\n\n---------------------------------\n' + dohod
bot.send_message(chat_id, '*' + notif + '*', parse_mode='Markdown')
print(notif)